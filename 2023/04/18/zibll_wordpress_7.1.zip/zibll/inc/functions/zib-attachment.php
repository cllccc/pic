<?php
/*
 * @Author        : Qinver
 * @Url           : zibll.com
 * @Date          : 2022-11-26 14:17:26
 * @LastEditTime: 2023-02-28 23:25:41
 * @Email         : 770349780@qq.com
 * @Project       : Zibll子比主题
 * @Description   : 一款极其优雅的Wordpress主题|附件相关函数
 * @Read me       : 感谢您使用子比主题，主题源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

//不显示附件页面
function zib_close_attachment_page()
{
    if (_pz('close_attachment_page')) {

        global $wp_query;
        if (is_attachment() && !is_super_admin()) {
            $wp_query->is_404 = (true);
        }
    }
}
add_action('template_redirect', 'zib_close_attachment_page');

// 上传文件自动重命名
function zib_new_filename($file)
{
    if (_pz('newfilename')) {
        $info         = pathinfo($file['name']);
        $ext          = empty($info['extension']) ? '' : '.' . $info['extension'];
        $md5          = md5($file['name']);
        $file['name'] = substr($md5, 0, 10) . current_time('His') . $ext;
    }
    return $file;
}
add_filter('wp_handle_upload_prefilter', 'zib_new_filename', 99);

/**
 * @description: 获取用户上传格式限制
 * @param {*} $user_id
 * @return {*}
 */
function zib_get_user_upload_mimes_limit($user_id = 0)
{
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    $options  = _pz('upload_file_mimes');
    $allow    = ''; //允许
    $prohibit = ''; //禁止

    if (isset($options[0])) {
        foreach ($options as $opt) {
            $type = $opt['type'];
            //只要登录就行
            if (zib_user_is_val_role($type, $user_id)) {
                if ($opt['pattern'] === 'prohibit') {
                    $prohibit .= ',' . $opt['val'];
                } else {
                    $allow .= ',' . $opt['val'];
                }
            }
        }
    }

    $allow    = ltrim(rtrim(trim($allow), ','), ',');
    $prohibit = ltrim(rtrim(trim($prohibit), ','), ',');

    $allow_array    = explode(',', $allow);
    $prohibit_array = explode(',', $prohibit);

    $mimes = array(
        'allow'    => array(),
        'prohibit' => array(),
    );

    foreach ($allow_array as $k) {
        $kv = explode('=', trim($k));
        if (count($kv) == 2 && trim($kv[0]) && trim($kv[1])) {
            $mimes['allow'][trim($kv[0])] = trim($kv[1]);
        }
    }

    foreach ($prohibit_array as $k) {
        $kv = explode('=', trim($k));
        if (count($kv) == 2 && trim($kv[0]) && trim($kv[1])) {
            $mimes['prohibit'][trim($kv[0])] = trim($kv[1]);
        }
    }

    return $mimes;
}

//添加系统允许上传的文件类型
function zib_upload_mimes_filter($mimes)
{
    $mimes = array_merge($mimes, zib_get_user_upload_mimes_limit()['allow']);
    $mimes = array_diff($mimes, zib_get_user_upload_mimes_limit()['prohibit']);

    return $mimes;
}
add_filter('upload_mimes', 'zib_upload_mimes_filter');

//在文章编辑页面的[添加媒体]只显示用户自己上传的文件
function zib_upload_media($wp_query_obj)
{
    global $current_user, $pagenow;
    if (!is_a($current_user, 'WP_User')) {
        return;
    }

    if ('admin-ajax.php' != $pagenow || 'query-attachments' != $_REQUEST['action']) {
        return;
    }

    if (!current_user_can('manage_options') && !current_user_can('manage_media_library')) {
        $wp_query_obj->set('author', $current_user->ID);
    }

    return;
}
add_action('pre_get_posts', 'zib_upload_media');

//在[媒体库]只显示用户上传的文件
function zib_media_library($wp_query)
{
    if (strpos($_SERVER['REQUEST_URI'], '/wp-admin/upload.php') !== false) {
        if (!current_user_can('manage_options') && !current_user_can('manage_media_library')) {
            global $current_user;
            $wp_query->set('author', $current_user->id);
        }
    }
}
add_filter('parse_query', 'zib_media_library');

/**
 * @description: 获取文章前台编辑：设置特色图像、视频、幻灯片的编辑框
 * @param {*} $post_id
 * @param {*} $class
 * @return {*}
 */
function zib_get_post_featured_edit_box($post_id, $class = 'mb20', $options = array())
{
    if (!get_current_user_id()) {
        return;
    }

    $can_video = apply_filters('featured_video_edit', false, $post_id);
    $can_slide = apply_filters('featured_slide_edit', false, $post_id);
    $can_image = apply_filters('featured_image_edit', false, $post_id);
    $args      = array();

    if (!$can_video && !$can_slide && !$can_image) {
        return;
    }

    if ($can_video && !$args && $post_id) {
        $video = get_post_meta($post_id, 'featured_video', true);
        if ($video) {
            $pic_url = get_post_meta($post_id, 'cover_image', true);

            $args['type'] = 'video';
            $args['data'] = array(
                'url' => $video,
                'pic' => $pic_url,
            );
        }
    }

    if ($can_slide && !$args && $post_id) {
        $slides_imgs = explode(',', get_post_meta($post_id, 'featured_slide', true));
        if (!empty($slides_imgs[0])) {
            $slides = array();
            foreach ($slides_imgs as $slides_img) {
                $background = zib_get_attachment_image_src((int) $slides_img, 'full');
                if (isset($background[0])) {
                    $slides[] = array(
                        'url' => $background[0],
                        'id'  => (int) $slides_img,
                    );
                }
            }
            if (isset($slides[0])) {
                $args['type'] = 'slide';
                $args['data'] = $slides;
            }
        }
    }

    if ($can_image && !$args && $post_id) {
        $img_url = get_post_meta($post_id, 'cover_image', true) ?: get_post_meta($post_id, 'thumbnail_url', true);
        if ($img_url) {
            $args['type'] = 'image';
            $args['data'] = array(
                'url' => $img_url,
            );
        }
    }

    $options['video'] = $can_video;
    $options['slide'] = $can_slide;
    $args['options']  = $options;

    return '<div class="' . $class . ' featured-edit" featured-args=\'' . json_encode($args) . '\'><div class="btns-full flex jc"></div></div>';
}

/**
 * @description: 上传图片函数
 * @param {*} $file
 * @param {*} $post_id
 * @param {*} $ajax_audit
 * @param {*} $msg_prefix
 * @return {*}
 */
function zib_php_upload($file = 'file', $post_id = 0, $ajax_audit = 'auto', $msg_prefix = '')
{
    if (empty($_FILES)) {
        return array('error' => 1, '_FILES' => '', 'msg' => '上传信息错误，请重新选择文件');
    }

    if ($_FILES) {
        require_once ABSPATH . "wp-admin" . '/includes/image.php';
        require_once ABSPATH . "wp-admin" . '/includes/file.php';
        require_once ABSPATH . "wp-admin" . '/includes/media.php';

        if ('auto' == $ajax_audit) {
            $ajax_audit = _pz('audit_upload_img', false);
        }

        //图片api审核
        if ($ajax_audit && stristr($_FILES[$file]['type'], 'image')) {
            ZibAudit::ajax_image($file, $msg_prefix);
        }

        $attach_id = media_handle_upload($file, $post_id);

        if (is_wp_error($attach_id)) {
            return array('error' => 1, '_FILES' => $_FILES, 'msg' => $attach_id->get_error_message());
        }

        $attach_id_s    = array();
        $_file_count_id = $file . '_file_count';
        if (!empty($_POST[$_file_count_id]) && $_POST[$_file_count_id] > 1) {
            for ($x = 1; $x < $_POST[$_file_count_id]; $x++) {
                $file_id = $file . '_' . $x;
                if (!empty($_FILES[$file_id])) {

                    //图片api审核
                    if ($ajax_audit && stristr($_FILES[$file_id]['type'], 'image')) {
                        ZibAudit::ajax_image($file_id, $msg_prefix);
                    }

                    $attach_id_x = media_handle_upload($file_id, $post_id);
                    if (!is_wp_error($attach_id_x)) {
                        $attach_id_s[] = $attach_id_x;
                    }
                }
            }
        }

        if ($attach_id_s) {
            array_unshift($attach_id_s, $attach_id);
            return $attach_id_s;
        } else {
            return $attach_id;
        }
    }
}

//js获取文件数据
function zib_prepare_attachment_for_js($attachment)
{

    $attachment_data = wp_prepare_attachment_for_js($attachment);

    if ($attachment_data['type'] === 'image') {
        $attachment_data['thumbnail_url'] = !empty($attachment_data['sizes']['thumbnail']['url']) ? $attachment_data['sizes']['thumbnail']['url'] : $attachment_data['url'];
        $attachment_data['medium_url']    = !empty($attachment_data['sizes']['medium']['url']) ? $attachment_data['sizes']['medium']['url'] : $attachment_data['url'];
        $attachment_data['large_url']     = !empty($attachment_data['sizes']['large']['url']) ? $attachment_data['sizes']['large']['url'] : $attachment_data['url'];
    }

    foreach (array('authorLink', 'editLink', 'icon', 'link', 'nonces') as $k) {
        if (isset($attachment_data[$k])) {
            unset($attachment_data[$k]);
        }
    }

    return $attachment_data;
}
