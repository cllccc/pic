<?php
/*
 * @Author        : Qinver
 * @Url           : zibll.com
 * @Date          : 2020-09-29 13:18:50
 * @LastEditTime: 2023-03-02 12:28:42
 * @Email         : 770349780@qq.com
 * @Project       : Zibll子比主题
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用子比主题，主题源码有详细的注释，支持二次开发。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

/**评论上传图片 */
/**私信上传图片 */
function zib_ajax_user_upload_image()
{
    //必须登录
    $cuid = get_current_user_id();
    if (!$cuid) {
        echo (json_encode(array('error' => 1, 'error_id' => 'nologged', 'ys' => 'danger', 'msg' => '请先登录')));
        exit;
    }

    if (!wp_verify_nonce($_POST['upload_image_nonce'], 'upload_image')) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => '安全验证失败，请稍候再试')));
        exit();
    }

    //开始上传
    $img_id = zib_php_upload();
    if (!empty($img_id['error'])) {
        echo (json_encode(array('error' => 1, 'ys' => 'danger', 'msg' => $img_id['msg'])));
        exit();
    }

    $size    = !empty($_REQUEST['size']) ? $_REQUEST['size'] : 'large';
    $img_url = wp_get_attachment_image_src($img_id, $size)[0];

    echo (json_encode(array('error' => '', 'ys' => '', 'msg' => '图片已上传', 'img_url' => $img_url)));
    exit();
}
add_action('wp_ajax_user_upload_image', 'zib_ajax_user_upload_image');
add_action('wp_ajax_nopriv_user_upload_image', 'zib_ajax_user_upload_image');

function zib_ajax_download_file()
{
    $file_id = isset($_GET['file']) ? (int) $_GET['file'] : 0;

    //执行安全验证检查
    if (!isset($_REQUEST['nonce']) || !wp_verify_nonce($_REQUEST['nonce'], 'download_file_' . $file_id)) {
        _default_wp_die_handler('下载链接已过期，请刷新页面重新下载！', '下载链接已过期');
    }

    $attachment = get_post($file_id);

    if (!isset($attachment->ID) || 'attachment' !== $attachment->post_type) {
        _default_wp_die_handler('抱歉！文件不存在或已删除！', '文件不存在');
    }

    //储存下载次数
    $download_amount = (int) get_post_meta($file_id, 'download_amount', true);
    update_post_meta($file_id, 'download_amount', $download_amount + 1);

    $file_dir = get_attached_file($file_id);

    if ($file_dir && file_exists($file_dir)) {
        //本地文件
        $temp = explode("/", $file_dir);

        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=\"" . end($temp) . "\"");
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: " . filesize($file_dir));
        ob_end_flush();
        @readfile($file_dir);
        exit;
    }

    $attachment_url = wp_get_attachment_url($attachment->ID);
    header('location:' . $attachment_url);
    echo '<html><head><meta name="robots" content="noindex,nofollow"><script>location.href = "' . $attachment_url . '";</script></head><body></body></html>';
    exit;

}
