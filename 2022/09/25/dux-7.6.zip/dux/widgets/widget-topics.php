<?php

class widget_ui_topics extends WP_Widget {

	function __construct(){
		parent::__construct( 'widget_ui_topics', 'DUX 专题', array( 'classname' => 'widget_ui_topics' ) );
	}

	function widget( $args, $instance ) {
		extract( $args );

		$title   = apply_filters('widget_name', $instance['title']);
		$limit   = isset($instance['limit']) ? $instance['limit'] : 6;
		$showtype = isset($instance['showtype']) ? $instance['showtype'] : 'text';

		echo $before_widget;
		echo $before_title.$title.$after_title; 
		echo '<ul class="-'.$showtype.'">';
			$lists = get_terms(array(
				'taxonomy'   => 'topic',
				'hide_empty' => false,
				'number'     => $limit,
			));

			foreach ($lists as $key => $item) {
				$link = get_term_link($item->term_id);
				echo '<li>';
	                echo '<a'._post_target_blank().' href="'. $link .'">';
						if( in_array($showtype, array('p1','p2')) ){
							echo '<img src="'. _get_tax_meta($item->term_id, 'image') .'" alt="'. $item->name .'">';
						}else{
							echo '<i class="fa fa-chevron-right"></i><i class="fa fa-book"></i>';
						}
	                	echo '<strong>'. $item->name .'</strong>';
	                echo '</a>';
				echo '</li>';
			}
		echo '</ul>';
		echo $after_widget;
	}

	function form( $instance ) {
		$defaults = array( 
			'title'   => '热门专题', 
			'limit'   => 4, 
			'showtype' => 'text', 
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
?>
		<p>
			<label>
				标题：
				<input style="width:100%;" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
			</label>
		</p>
		<p>
			<label>
				模式：
				<select style="width:100%;" id="<?php echo $this->get_field_id('showtype'); ?>" name="<?php echo $this->get_field_name('showtype'); ?>" style="width:100%;">
					<option value="p1" <?php selected('p1', $instance['showtype']); ?>>一行一图</option>
					<option value="p2" <?php selected('p2', $instance['showtype']); ?>>一行二图</option>
					<option value="text" <?php selected('text', $instance['showtype']); ?>>无图</option>
				</select>
			</label>
		</p>
		<p>
			<label>
				显示数目：
				<input style="width:100%;" id="<?php echo $this->get_field_id('limit'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="number" value="<?php echo $instance['limit']; ?>" size="24" />
			</label>
		</p>
		
	<?php
	}
}
