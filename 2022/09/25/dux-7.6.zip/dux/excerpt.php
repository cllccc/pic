<?php
/**
 * Used for index/archive/search/author/catgory/tag.
 *
 */

global $sticky_ids;
$ii = 0;
while ( have_posts() ) : the_post(); 

    $_thumb = _get_post_thumbnail();
    $no_thumb = strstr($_thumb, 'data-thumb="default"');

    $_excerpt_text = '';
    if( _hui('list_type')=='text' || (_hui('list_type') == 'thumb_if_has' && $no_thumb) ){
        $_excerpt_text .= ' excerpt-text';
    }
    if( _hui('home_sticky_s') && is_array($sticky_ids) && in_array(get_the_ID(), $sticky_ids) && $paged<=1 ){
        $_excerpt_text .= ' excerpt-sticky';
    }
    if( hui_is_post_new() ){
        $_excerpt_text .= ' excerpt-latest';
    }
    

    $ii++;

    if( $ii == 3 && _hui('ads_list3_s') ){
        echo '<article class="excerpt'.( _hui('ads_list3_src') ? '' : ' excerpt-text' ).'">';
        if( _hui('ads_list3_src') ){
            echo '<a href="'._hui('ads_list3_link').'" target="_blank" class="focus"><img src="'._hui('ads_list3_src').'" class="thumb"></a>';
        }
        echo '<header><h2><a target="_blank" href="'._hui('ads_list3_link').'">'._hui('ads_list3_title').'</a></h2></header><p class="note">'._hui('ads_list3_info').'</p><div class="meta"><time>'.date('Y-m-d').'</time></div></article>';
    }

    echo '<article class="excerpt excerpt-'.$ii. $_excerpt_text .'">';

        if( _hui('list_type') == 'thumb' || (_hui('list_type') == 'thumb_if_has' && !$no_thumb) ){
            echo '<a'._post_target_blank().' class="focus" href="'.get_permalink().'">'.$_thumb.'</a>';
        }

        echo '<header>';
            if( _hui('home_sticky_s') && is_array($sticky_ids) && in_array(get_the_ID(), $sticky_ids) && $paged<=1 ){
                echo '<span class="sticky-icon">置顶</span>';
            }
            echo '<h2><a'._post_target_blank().' href="'.get_permalink().'" title="'.get_the_title().get_the_subtitle(false)._get_delimiter().get_bloginfo('name').'">'.get_the_title().get_the_subtitle().'</a></h2>';
        echo '</header>';

        $excp = _get_excerpt(80);
        if( $excp ) echo '<p class="note">'.$excp.'</p>';

        echo '<div class="meta">';
            
            if( _hui('post_plugin_author') ){
                $authorname = get_the_author();
                $author = '<img class="avatar" data-src="'.get_avatar_url(get_the_author_meta('ID')).'" src="'._get_default_avatar().'" alt="'.$authorname.'">';
                if( _hui('author_link') ){
                    $author .= '<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.$authorname.'</a>';
                }else{
                    $author .= $authorname;
                }
                echo '<span class="author">'.$author.'</span>';
            }
            
            if( _hui('post_plugin_date') ){
                echo '<time>'.get_the_time('Y-m-d').'</time>';
            }

            if( _hui('post_plugin_cat') && !is_category() ) {
                $category = get_the_category();
                if($category && $category[0]){
                    echo '<a class="cat" href="'.get_category_link($category[0]->term_id ).'"><i class="fa fa-book-reader"></i>'.$category[0]->cat_name.'</a> ';
                }
            }

            if( _hui('post_plugin_view') ){
                echo '<span class="pv">'._get_post_views().'</span>';
            }

            if ( !_hui('kill_comment_s') && comments_open() && _hui('post_plugin_comm') ) {
                echo '<a class="pc" href="'.get_comments_link().'">评论('.get_comments_number('0', '1', '%').')</a>';
            }

            if( _hui('post_link_excerpt_s') ){
                $link = get_post_meta($post->ID, 'link', true);
                if( $link ) echo '<a class="zlink" href="'. $link .'" target="_blank"' . (_hui('post_link_nofollow_s')?' rel="external nofollow"':'') .'><i class="fas fa-compass"></i>'._hui('post_link_h1') .'</a>';
            }

            if( _hui('post_plugin_like') ){
                echo hui_get_post_like($class='post-like');
            }

        echo '</div>';

    echo '</article>';

endwhile; 